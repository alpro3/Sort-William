
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 14201805
 */
public class Matrizes {
    
    
    public static void main(String[] args) {
        
        tabela5x6();
        
        
        
    }
    
    private static void tabela5x6(){
        int m[][] = new int[5][6];
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                m[i][j] = i+j;
            }
        }

        
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                System.out.print(m[i][j] + " ");
            }
            System.out.println();
        }
        System.out.println();
        for (int i = 0; i < m[0].length; i++) {
            for (int j = 0; j < m.length; j++) {
                System.out.print(m[j][i] + " ");
            }
            System.out.println();
        }
    }
    
    private static void multMatrizes(int m1[][], int m2[][]){
        
    }
    
    private static void somaMatrizes(int m1[][], int m2[][]){
        
    }
    
    private static void transMatrizes(int m1[][], int m2[][]){
        
    }
}
